from qgis.PyQt.QtCore import QEvent, QObject, QSettings, QTimer, Qt
from qgis.PyQt.QtWidgets import (
    QAbstractSpinBox,
    QAction,
    QApplication,
    QComboBox,
    QLineEdit,
    QPlainTextEdit,
    QTextEdit,
)
from qgis.PyQt.QtGui import QColor, QCursor, QIcon, QPainter, QPen, QPixmap
from qgis.core import (
    Qgis,
    QgsFeature,
    QgsFeatureRequest,
    QgsGeometry,
    QgsMessageLog,
    QgsProject,
    QgsRasterLayer,
    QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.gui import QgsMapToolIdentifyFeature


class _QgisKeyFilter(QObject):
    def __init__(self, plugin):
        super().__init__()
        self.plugin = plugin

    def eventFilter(self, watched, event):
        if event.type() not in (QEvent.KeyPress, QEvent.KeyRelease):
            return False
        if event.key() not in (Qt.Key_Space, Qt.Key_E, Qt.Key_Escape):
            return False
        if event.modifiers() != Qt.NoModifier:
            return False

        app = QApplication.instance()
        if (
            app.activeWindow() is not self.plugin.iface.mainWindow()
            or app.activeModalWidget() is not None
            or app.activePopupWidget() is not None
        ):
            return False

        focus_widget = app.focusWidget()
        if isinstance(
            focus_widget,
            (QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QAbstractSpinBox),
        ):
            return False

        if event.type() == QEvent.KeyPress and not event.isAutoRepeat():
            if event.key() == Qt.Key_Space:
                self.plugin.toggle_visibility()
            elif event.key() == Qt.Key_E:
                self.plugin.activate_click_delete()
            else:
                self.plugin.cancel_click_delete()
        return True


class ToggleXX202607:
    MAX_IMAGERY_LAYERS = 2
    VERSION = "1.5.1"
    MERGE_SETTINGS_KEY = "toggle_xx202607/auto_merge_overlap"
    # 面积相对阈值：交集面积低于两要素面积和的该比例时视为贴边而非重叠
    OVERLAP_REL_EPS = 1e-12

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.delete_action = None
        self.merge_action = None
        self.space_filter = None
        self.delete_tool = None
        self.delete_target_layer = None
        self.previous_map_tool = None
        self.digitizing_cursor = self.create_digitizing_cursor()
        self.digitizing_cursor_applied = False
        # 每个面图层一份：因自动合并而被删除的要素 fid，
        # 撤销（Ctrl+Z）恢复这些要素时会再次发出 featureAdded，用该集合跳过。
        self._auto_deleted_fids = {}
        self._merge_slots = {}
        self._merge_busy = False
        self._merge_enabled = True

    def initGui(self):
        icon_path = __file__.replace("toggle_xx202607.py", "icon.svg")
        self.action = QAction(
            QIcon(icon_path),
            "互斥切换影像",
            self.iface.mainWindow(),
        )
        self.action.setToolTip(
            "在最大两张影像之间互斥切换（地图画布中按空格键）"
        )
        self.action.triggered.connect(self.toggle_visibility)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&影像快捷切换", self.action)

        self.delete_action = QAction(
            "单击删除一个要素（E）",
            self.iface.mainWindow(),
        )
        self.delete_action.setToolTip(
            "按 E 或点击此按钮，然后单击当前编辑图层中的要素以删除"
        )
        self.delete_action.triggered.connect(self.activate_click_delete)
        self.iface.addToolBarIcon(self.delete_action)
        self.iface.addPluginToMenu("&影像快捷切换", self.delete_action)

        settings = QSettings()
        self._merge_enabled = settings.value(
            self.MERGE_SETTINGS_KEY, True, type=bool
        )
        self.merge_action = QAction(
            "新建面要素自动合并重叠", self.iface.mainWindow()
        )
        self.merge_action.setCheckable(True)
        self.merge_action.setChecked(self._merge_enabled)
        self.merge_action.setToolTip(
            "开启后，新画的面要素若与同图层已有要素存在面积重叠，"
            "会自动把重叠部分合并成一个要素，而不是叠放多个要素"
        )
        self.merge_action.toggled.connect(self.set_auto_merge_enabled)
        self.iface.addPluginToMenu("&影像快捷切换", self.merge_action)

        project = QgsProject.instance()
        project.layersAdded.connect(self.on_layers_added)
        project.layersWillBeRemoved.connect(self.on_layers_removed)
        for layer in project.mapLayers().values():
            self.connect_merge_layer(layer)

        self.delete_tool = QgsMapToolIdentifyFeature(self.iface.mapCanvas())
        self.delete_tool.featureIdentified.connect(self.delete_identified_feature)
        self.iface.mapCanvas().mapToolSet.connect(self.on_map_tool_set)
        self.iface.currentLayerChanged.connect(self.on_current_layer_changed)
        QTimer.singleShot(0, self.update_digitizing_cursor)

        self.space_filter = _QgisKeyFilter(self)
        QApplication.instance().installEventFilter(self.space_filter)
        self.iface.mainWindow().statusBar().showMessage(
            "影像快捷切换 {} 已加载：空格互斥切影像；E 后单击删要素；"
            "新建面与已有要素重叠自动合并（当前{}）。".format(
                self.VERSION,
                "已开启" if self._merge_enabled else "已关闭",
            ),
            5000,
        )

    def unload(self):
        self.cancel_click_delete()
        if self.digitizing_cursor_applied:
            self.iface.mapCanvas().unsetCursor()
            self.digitizing_cursor_applied = False
        try:
            self.iface.mapCanvas().mapToolSet.disconnect(self.on_map_tool_set)
        except (TypeError, RuntimeError):
            pass
        try:
            self.iface.currentLayerChanged.disconnect(self.on_current_layer_changed)
        except (TypeError, RuntimeError):
            pass
        project = QgsProject.instance()
        try:
            project.layersAdded.disconnect(self.on_layers_added)
        except (TypeError, RuntimeError):
            pass
        try:
            project.layersWillBeRemoved.disconnect(self.on_layers_removed)
        except (TypeError, RuntimeError):
            pass
        for layer in project.mapLayers().values():
            self.disconnect_merge_layer(layer)
        self._auto_deleted_fids.clear()
        if self.space_filter is not None:
            QApplication.instance().removeEventFilter(self.space_filter)
            self.space_filter = None
        if self.merge_action is not None:
            self.iface.removePluginMenu("&影像快捷切换", self.merge_action)
            self.merge_action.deleteLater()
            self.merge_action = None
        if self.delete_action is not None:
            self.iface.removeToolBarIcon(self.delete_action)
            self.iface.removePluginMenu("&影像快捷切换", self.delete_action)
            self.delete_action.deleteLater()
            self.delete_action = None
        if self.action is not None:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu("&影像快捷切换", self.action)
            self.action.deleteLater()
            self.action = None

    def activate_click_delete(self):
        if self.delete_target_layer is not None:
            self.cancel_click_delete()
            self.iface.mainWindow().statusBar().showMessage("已取消单击删除。", 1500)
            return

        layer = self.iface.activeLayer()
        if not isinstance(layer, QgsVectorLayer):
            self.iface.messageBar().pushWarning(
                "单击删除",
                "请先选中要删除要素所在的矢量图层。",
            )
            return
        if not layer.isEditable():
            self.iface.messageBar().pushWarning(
                "单击删除",
                "请先点击铅笔按钮，开启当前图层的编辑状态。",
            )
            return

        canvas = self.iface.mapCanvas()
        self.cancel_click_delete()
        self.delete_target_layer = layer
        self.previous_map_tool = canvas.mapTool()
        self.delete_tool.setLayer(layer)
        canvas.setMapTool(self.delete_tool)
        self.iface.mainWindow().statusBar().showMessage(
            "单击要删除的要素；按 Esc 或再次按 E 可取消。",
            3000,
        )

    def delete_identified_feature(self, feature):
        layer = self.delete_target_layer
        if layer is None or not layer.isEditable():
            self.cancel_click_delete()
            return

        if layer.deleteFeature(feature.id()):
            self.iface.mapCanvas().refresh()
            self.iface.mainWindow().statusBar().showMessage(
                "已删除一个要素；按 Ctrl+Z 可以撤销。",
                2500,
            )
        else:
            self.iface.messageBar().pushWarning("单击删除", "删除失败。")
        self.cancel_click_delete()

    def cancel_click_delete(self):
        if self.previous_map_tool is not None:
            self.iface.mapCanvas().setMapTool(self.previous_map_tool)
        self.previous_map_tool = None
        self.delete_target_layer = None

    # ------------------------------------------------------------------
    # 新建面要素自动合并重叠
    # ------------------------------------------------------------------

    def set_auto_merge_enabled(self, checked):
        self._merge_enabled = checked
        QSettings().setValue(self.MERGE_SETTINGS_KEY, checked)
        self.iface.mainWindow().statusBar().showMessage(
            "新建面要素自动合并重叠：{}。".format("已开启" if checked else "已关闭"),
            2000,
        )

    def on_layers_added(self, layers):
        for layer in layers:
            self.connect_merge_layer(layer)

    def on_layers_removed(self, layers):
        project = QgsProject.instance()
        for item in layers:
            # 信号可能传图层 ID（str）或图层对象，两种都兼容
            layer = project.mapLayer(item) if isinstance(item, str) else item
            if layer is None:
                continue
            self.disconnect_merge_layer(layer)
            self._auto_deleted_fids.pop(layer.id(), None)

    def connect_merge_layer(self, layer):
        if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
            return
        if layer.geometryType() != QgsWkbTypes.PolygonGeometry:
            return
        layer_id = layer.id()
        if layer_id in self._merge_slots:
            return

        def _slot(fid, lyr=layer):
            self._on_feature_added(lyr, fid)

        self._merge_slots[layer_id] = _slot
        layer.featureAdded.connect(_slot)

    def disconnect_merge_layer(self, layer):
        if not isinstance(layer, QgsVectorLayer):
            return
        slot = self._merge_slots.pop(layer.id(), None)
        if slot is not None:
            try:
                layer.featureAdded.disconnect(slot)
            except (TypeError, RuntimeError):
                pass

    def _on_feature_added(self, layer, fid):
        if not self._merge_enabled or self._merge_busy:
            return
        guard = self._auto_deleted_fids.get(layer.id())
        if guard is not None and fid in guard:
            # 该要素是被自动合并删除后经撤销恢复的，跳过，保证 Ctrl+Z 可正常撤销
            guard.discard(fid)
            return
        # 延迟到数字化工具收尾之后再处理，避免在信号回调中改图层
        QTimer.singleShot(0, lambda: self._merge_overlaps(layer, fid))

    @staticmethod
    def _valid_copy(geom):
        """返回可用于叠加运算的几何副本：无效几何（如自相交面）先修复。"""
        if geom is None or geom.isEmpty():
            return None
        if geom.isGeosValid():
            return geom
        fixed = geom.makeValid()
        if fixed is None or fixed.isEmpty():
            return None
        return fixed

    @classmethod
    def _has_area_overlap(cls, geom_a, geom_b):
        """两条几何存在真实面积重叠（贴边/共线不算）。"""
        try:
            inter = geom_a.intersection(geom_b)
        except RuntimeError:
            return False
        if inter is None or inter.isEmpty():
            return False
        threshold = (geom_a.area() + geom_b.area()) * cls.OVERLAP_REL_EPS
        return inter.area() > threshold

    def _merge_overlaps(self, layer, fid, _attempt=0):
        if self._merge_busy:
            # 上一轮合并尚未结束（如连续快速添加/粘贴多个要素）：排队重试
            if _attempt < 100:
                QTimer.singleShot(
                    20, lambda: self._merge_overlaps(layer, fid, _attempt + 1)
                )
            return
        self._merge_busy = True
        try:
            self._do_merge(layer, fid)
        finally:
            self._merge_busy = False

    def _do_merge(self, layer, fid):
        try:
            if not layer.isEditable():
                return
            if layer.geometryType() != QgsWkbTypes.PolygonGeometry:
                return
            try:
                new_feature = layer.getFeature(fid)
            except (KeyError, RuntimeError):
                return
            new_geom = self._valid_copy(new_feature.geometry())
            if new_geom is None:
                return

            # 从新要素出发，沿“面积重叠”关系扩散，找齐所有相互重叠的既有要素
            cluster_ids = set()
            merged_geoms = [new_geom]
            while True:
                try:
                    union_so_far = QgsGeometry.unaryUnion(merged_geoms)
                except RuntimeError:
                    union_so_far = QgsGeometry()
                if union_so_far is None or union_so_far.isEmpty():
                    self._report_merge_error(layer, "几何运算失败，本次未自动合并。")
                    return
                request = QgsFeatureRequest(union_so_far.boundingBox())
                request.setFlags(QgsFeatureRequest.ExactIntersect)
                found_new = False
                for candidate in layer.getFeatures(request):
                    candidate_id = candidate.id()
                    if candidate_id == fid or candidate_id in cluster_ids:
                        continue
                    candidate_geom = self._valid_copy(candidate.geometry())
                    if candidate_geom is None:
                        continue
                    if not self._has_area_overlap(union_so_far, candidate_geom):
                        continue
                    cluster_ids.add(candidate_id)
                    merged_geoms.append(candidate_geom)
                    found_new = True
                if not found_new:
                    break

            if not cluster_ids:
                return

            try:
                merged = QgsGeometry.unaryUnion(merged_geoms)
            except RuntimeError:
                merged = QgsGeometry()
            if merged is not None and not merged.isEmpty() and not merged.isGeosValid():
                merged = merged.makeValid()
            if merged is None or merged.isEmpty():
                self._report_merge_error(layer, "合并几何生成失败，本次未自动合并。")
                return

            main_geom, extra_parts = self._match_layer_wkbtype(layer, merged)

            layer.beginEditCommand("合并重叠要素")
            ok = True
            for delete_id in sorted(cluster_ids):
                if not layer.deleteFeature(delete_id):
                    ok = False
                    break
            if ok:
                ok = layer.changeGeometry(fid, main_geom)
            if ok:
                # GPKG 等会把主键（fid）暴露为属性且预分配最终 fid：
                # 直接复制属性会让新部件带着与主要素相同的主键值入库，
                # 提交时 INSERT 撞 UNIQUE 约束，部件丢失。主键字段必须置空。
                pk_indexes = layer.primaryKeyAttributes()
                source_attrs = list(new_feature.attributes())
                for idx in pk_indexes:
                    if 0 <= idx < len(source_attrs):
                        source_attrs[idx] = None
                for part in extra_parts:
                    feature = QgsFeature(layer.fields())
                    feature.setAttributes(source_attrs)
                    feature.setGeometry(part)
                    if not layer.addFeature(feature):
                        ok = False
                        break
            if ok:
                layer.endEditCommand()
                self._auto_deleted_fids.setdefault(layer.id(), set()).update(
                    cluster_ids
                )
                self.iface.mapCanvas().refresh()
                if extra_parts:
                    self.iface.mainWindow().statusBar().showMessage(
                        "已合并重叠要素；另有 {} 个分离部件已存为独立新要素；Ctrl+Z 可整体撤销。".format(
                            len(extra_parts)
                        ),
                        3500,
                    )
                else:
                    self.iface.mainWindow().statusBar().showMessage(
                        "新要素与 {} 个已有要素重叠，已合并为一个要素；Ctrl+Z 可整体撤销。".format(
                            len(cluster_ids)
                        ),
                        3000,
                    )
            else:
                layer.destroyEditCommand()
                self._report_merge_error(layer, "无法写入合并结果，已保留原要素。")
        except Exception as exc:  # 任何意外都不应中断数字化
            self._report_merge_error(layer, "内部错误：{}".format(exc))

    @staticmethod
    def _match_layer_wkbtype(layer, merged):
        """使合并结果与图层几何类型兼容，避免 GDAL 把多部件强转为非法单部件面。

        返回 (写入新要素的主几何, 需另存为独立要素的其他部件)。
        """
        single_layer = QgsWkbTypes.isSingleType(layer.wkbType())
        if single_layer and merged.isMultipart():
            parts = [
                QgsGeometry.fromPolygonXY(poly)
                for poly in merged.asMultiPolygon()
            ]
            parts.sort(key=lambda geom: geom.area(), reverse=True)
            return parts[0], parts[1:]
        if not single_layer and not merged.isMultipart():
            return QgsGeometry.fromMultiPolygonXY([merged.asPolygon()]), []
        return merged, []

    def _report_merge_error(self, layer, reason):
        self.iface.messageBar().pushWarning("自动合并重叠", reason)
        try:
            QgsMessageLog.logMessage(
                "自动合并重叠 [图层 {}]: {}".format(layer.name(), reason),
                "影像快捷切换",
                Qgis.MessageLevel.Warning,
            )
        except RuntimeError:
            pass

    def on_map_tool_set(self, new_map_tool, *unused):
        if (
            self.delete_target_layer is not None
            and new_map_tool is not self.delete_tool
        ):
            self.previous_map_tool = None
            self.delete_target_layer = None
        QTimer.singleShot(0, self.update_digitizing_cursor)

    def on_current_layer_changed(self, layer):
        if layer is not None:
            # 兜底：确保当前图层一定挂上了合并监听
            self.connect_merge_layer(layer)
        QTimer.singleShot(50, self.update_digitizing_cursor)

    @staticmethod
    def create_digitizing_cursor():
        pixmap = QPixmap(21, 21)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing, False)

        black_pen = QPen(QColor("#111111"))
        black_pen.setWidth(3)
        painter.setPen(black_pen)
        painter.drawLine(1, 10, 19, 10)

        painter.drawLine(10, 1, 10, 19)

        white_pen = QPen(QColor("#ffffff"))
        white_pen.setWidth(1)
        painter.setPen(white_pen)
        painter.drawLine(1, 10, 19, 10)
        painter.drawLine(10, 1, 10, 19)
        painter.end()
        return QCursor(pixmap, 10, 10)

    def update_digitizing_cursor(self):
        add_feature_action = self.iface.actionAddFeature()
        add_feature_active = (
            add_feature_action is not None and add_feature_action.isChecked()
        )
        canvas = self.iface.mapCanvas()
        if add_feature_active:
            canvas.setCursor(self.digitizing_cursor)
            self.digitizing_cursor_applied = True
        elif self.digitizing_cursor_applied:
            canvas.unsetCursor()
            self.digitizing_cursor_applied = False

    def _resolve_imagedata(self):
        """按像素数找出工程中最大的两张影像图层，不依赖图层名。"""
        project = QgsProject.instance()
        candidates = [
            layer
            for layer in project.mapLayers().values()
            if isinstance(layer, QgsRasterLayer) and layer.isValid()
        ]
        largest = sorted(
            candidates,
            key=lambda layer: layer.width() * layer.height(),
            reverse=True,
        )[: self.MAX_IMAGERY_LAYERS]
        return [project.layerTreeRoot().findLayer(lyr.id()) for lyr in largest]

    def toggle_visibility(self):
        nodes = [node for node in self._resolve_imagedata() if node is not None]
        if len(nodes) < 2:
            self.iface.messageBar().pushWarning(
                "影像快捷切换",
                "当前工程中的影像（栅格）图层不足两个，无法切换。",
            )
            return

        # 两张影像始终互斥：无论当前是一张可见、两张可见还是都隐藏，
        # 每按一次空格都保证恰好显示其中一张。
        show_first = not nodes[0].itemVisibilityChecked()
        for index, node in enumerate(nodes):
            node.setItemVisibilityChecked(show_first if index == 0 else not show_first)

        self.iface.mapCanvas().refresh()
        shown_layer = nodes[0].layer().name() if show_first else nodes[1].layer().name()
        self.iface.mainWindow().statusBar().showMessage(
            "正在显示 {}；当前编辑图层未改变。".format(shown_layer),
            2000,
        )
