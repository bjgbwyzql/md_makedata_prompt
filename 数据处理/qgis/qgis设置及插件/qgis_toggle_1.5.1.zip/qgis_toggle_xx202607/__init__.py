def classFactory(iface):
    from .toggle_xx202607 import ToggleXX202607
    return ToggleXX202607(iface)
